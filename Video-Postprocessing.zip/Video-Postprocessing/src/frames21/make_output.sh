ffmpeg -i ../Level_02_Crack_glass.mp4 -r 30 -start_number 0 frame_%03d.png
rm frame_000.png
ffmpeg -framerate 30 -i frame_%03d.png -frames 240 -r 30 -pix_fmt yuv420p -crf 12 output.mp4
